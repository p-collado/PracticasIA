background = drawBackground(window_layer, "wow")
health_bar_prop = drawCreature(window_layer, "health_bar")
health_prop = drawCreature(window_layer, "mage")
setPropPosition(health_prop, 118, 52)